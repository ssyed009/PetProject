package helpers;
import com.github.javafaker.Faker;

public class DataGenerator {
    
    static Faker faker = new Faker();

    public static String getRandomId() {
        String petId = faker.random().nextInt(0, 10000).toString();
        return petId;
    }

    public static String getRandomPetName() {
        String petName = faker.cat().name();
        return petName;
    }
}
