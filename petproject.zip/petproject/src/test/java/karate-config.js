function fn() {
  var env = karate.env; // get system property 'karate.env'
  karate.log("karate.env system property was:", env);
  if (!env) {
    env = "QA";
  }
  var config = {
    env: env,
    petstoreURL: "https://petstore.swagger.io/v2/",
  };
  if (env == "QA") {
    config.petstoreURL = "https://petstore.swagger.io/v2/";
  } else if (env == "Dev") {
    // customize
  } else if (env == "Staging") {
    // customize
  }
  return config;
}
